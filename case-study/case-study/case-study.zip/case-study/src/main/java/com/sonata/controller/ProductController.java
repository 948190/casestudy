package com.sonata.controller;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.sonata.model.Brand;
import com.sonata.model.Product;
import com.sonata.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductService productService;
    
    //1.Fetch a data of particular products based on its Id, which has max price
    
    @GetMapping("/maxprice")
    public ResponseEntity<Product> getProductWithMaxPriceByCategory(@RequestParam String categoryName) {
        Product maxPriceProduct = productService.getProductWithMaxPriceByCategory(categoryName);

        
            return new ResponseEntity<>(maxPriceProduct, HttpStatus.OK);
        
        }

    //2.No. Of products per brands
    @GetMapping("/products-per-brand")
    public ResponseEntity<Map<String, Long>> getProductsPerBrand() {
        Map<String, Long> productCountPerBrand = productService.getProductsPerBrand();
        return new ResponseEntity<>(productCountPerBrand, HttpStatus.OK);
    }
    
    //3.List of products Group by price
    @GetMapping("/products-grouped-by-price")
    public ResponseEntity<Map<Double, List<Product>>>
    getProductsGroupedByPrice() {
        Map<Double, List<Product>> productsGroupedByPrice = productService.getProductsGroupedByPrice();
        return new ResponseEntity<>(productsGroupedByPrice, HttpStatus.OK);
    }
    //4.
    @GetMapping("/products-grouped-by-color")
    public ResponseEntity<Map<String, List<Product>>>
    getProductsGroupedByColor() {
        Map<String, List<Product>> productsGroupedByColor = productService.getProductsGroupedByColor();
        return new ResponseEntity<>(productsGroupedByColor, HttpStatus.OK);
    }
    
    @GetMapping("/products-by-color")
    public ResponseEntity<List<Product>> getProductsByColor(@RequestParam String color) {
        List<Product> productsByColor = productService.getProductsByColor(color);
        return new ResponseEntity<>(productsByColor, HttpStatus.OK);
    }
    //5.List of products group by size
    @GetMapping("/products-grouped-by-size")
    public ResponseEntity<Map<String, List<Product>>>
    getProductsGroupedBySize() {
        Map<String, List<Product>> productsGroupedBySize = productService.getProductsGroupedBySize();
        return new ResponseEntity<>(productsGroupedBySize, HttpStatus.OK);
    }
    
    //6.List of products group by brands
    @GetMapping("/products-grouped-by-brand")
    public ResponseEntity<Map<String, List<Product>>> getProductsGroupedByBrand() {
        Map<String, List<Product>> productsGroupedByBrand = productService.getProductsGroupedByBrand();
        return new ResponseEntity<>(productsGroupedByBrand, HttpStatus.OK);
    }

    @PostMapping("/create")
    public ResponseEntity<String> createProduct(@RequestBody Product productDTO) {
        try {
            Product createdProduct = productService.createProduct(productDTO);
            return new ResponseEntity<>("Product created successfully with ID: " + createdProduct.getProductId(), HttpStatus.CREATED);
        } catch (Exception e) {
            
            return new ResponseEntity<>("Failed to create the product: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
}
