package com.sonata.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sonata.model.Brand;
import com.sonata.model.Category;
import com.sonata.model.Product;
import com.sonata.repo.BrandRepository;
import com.sonata.repo.CategoryRepository;
import com.sonata.repo.ProductRepository;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private BrandRepository brandRepository;
    @Autowired
    private CategoryRepository categoryRepository;
    
    //1
    public Product getProductWithMaxPriceByCategory(String categoryName) {
        Category category = categoryRepository.findByName(categoryName);

        if (category == null) {
            return null;
        }

        List<Product> productsInCategory = productRepository.findByCategory(category);

        if (productsInCategory.isEmpty()) {
            return null;
        }

        return productsInCategory.stream()
                .max(Comparator.comparing(Product::getPrice))
                .orElse(null);
    }
    
    //2
    public Map<String, Long> getProductsPerBrand() {
        
        List<Product> products = productRepository.findAll();
        return products.stream()
                .collect(Collectors.groupingBy(product -> product.getBrand().getName(),
                        Collectors.counting()));
    }
    
    //3
    public Map<Double, List<Product>> getProductsGroupedByPrice() {
        List<Product> products = productRepository.findAll();
        return products.stream().collect(Collectors.groupingBy(Product::getPrice));
    }
    
    //4
    public Map<String, List<Product>> getProductsGroupedByColor() {
        List<Product> products = productRepository.findAll();
        return products.stream().collect(Collectors.groupingBy(Product::getColor));
    }
    
    public List<Product> getProductsByColor(String color) {
        
        return productRepository.findByColor(color);
    }
    
    //5
    
    public Map<String, List<Product>> getProductsGroupedBySize() {
        List<Product> products = productRepository.findAll();
        return products.stream().collect(Collectors.groupingBy(Product::getSize));
    }
    
    //6
    public Map<String, List<Product>> getProductsGroupedByBrand() {
        List<Product> products = productRepository.findAll();

        Map<String, List<Product>> productsGroupedByBrand = new HashMap<>();

        for (Product product : products) {
            String brandName = product.getBrand().getName(); 
            List<Product> productList = productsGroupedByBrand.getOrDefault(brandName, new ArrayList<>());

            productList.add(product);
            productsGroupedByBrand.put(brandName, productList);
        }

        return productsGroupedByBrand;
    }



    
    

    public Product createProduct(Product product) {
        
        Brand brand = brandRepository.findByName(product.getBrand().getName());
        
        if (brand == null) {
            
        	brand = new Brand();
            brand.setName(product.getBrand().getName());
            brand = brandRepository.save(brand);
        }

        
        Category category = categoryRepository.findByName(product.getCategory().getName());
         if (category == null) {
            
            category = new Category();
            category.setName(product.getCategory().getName());
            category = categoryRepository.save(category);
        }

        
        Product newProduct = new Product();
        newProduct.setName(product.getName());
        newProduct.setPrice(product.getPrice());
        newProduct.setColor(product.getColor());
        newProduct.setSize(product.getSize());
        newProduct.setBrand(brand);
        newProduct.setCategory(category);

        
        return productRepository.save(newProduct);
    }
}
